---
title: "DNS server API reference"
symbol_kind: "intro"
decl_name: "dns_server.h"
items:
  - { name: mg_dns_create_reply.md }
  - { name: mg_dns_reply_record.md }
  - { name: mg_dns_send_reply.md }
---

Disabled by default; enable with `-DMG_ENABLE_DNS_SERVER`.

