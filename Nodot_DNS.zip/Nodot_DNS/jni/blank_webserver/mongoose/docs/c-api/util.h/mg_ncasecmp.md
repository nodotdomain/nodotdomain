---
title: "mg_ncasecmp()"
decl_name: "mg_ncasecmp"
symbol_kind: "func"
signature: |
  int mg_ncasecmp(const char *s1, const char *s2, size_t len);
---

Cross-platform version of `strncasecmp()`. 

