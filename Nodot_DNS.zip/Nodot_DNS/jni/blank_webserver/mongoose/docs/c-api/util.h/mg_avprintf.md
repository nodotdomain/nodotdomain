---
title: "mg_avprintf()"
decl_name: "mg_avprintf"
symbol_kind: "func"
signature: |
  int mg_avprintf(char **buf, size_t size, const char *fmt, va_list ap);
---

Same as mg_asprintf, but takes varargs list. 

