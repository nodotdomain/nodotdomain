---
title: "mg_vcmp()"
decl_name: "mg_vcmp"
symbol_kind: "func"
signature: |
  int mg_vcmp(const struct mg_str *str2, const char *str1);
---

Cross-platform version of `strcmp()` where where first string is
specified by `struct mg_str`. 

