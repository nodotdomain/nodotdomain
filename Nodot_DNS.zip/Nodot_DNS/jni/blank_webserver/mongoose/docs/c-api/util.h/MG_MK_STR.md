---
title:
"MG_MK_STR()"
decl_name:
"MG_MK_STR"
symbol_kind:
"func"
signature:
|
#define MG_MK_STR(str_literal);
---

Macro for
initializing mg_str
.

