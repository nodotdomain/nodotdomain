---
title: "DNS server"
symbol_kind: "intro"
decl_name: "dns-server.h"
---

Disabled by default; enable with `-DMG_ENABLE_DNS_SERVER`.

