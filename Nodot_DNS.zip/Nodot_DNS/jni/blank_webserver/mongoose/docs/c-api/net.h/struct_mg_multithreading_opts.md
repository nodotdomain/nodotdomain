---
title: "struct mg_multithreading_opts"
decl_name: "struct mg_multithreading_opts"
symbol_kind: "struct"
signature: |
  struct mg_multithreading_opts {
    int poll_timeout; /* Polling interval */
  };
---

Optional parameters for mg_enable_multithreading_opt() 

