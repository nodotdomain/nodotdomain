---
title: "struct mg_str"
decl_name: "struct mg_str"
symbol_kind: "struct"
signature: |
  struct mg_str {
    const char *p; /* Memory chunk pointer */
    size_t len;    /* Memory chunk length */
  };
---

Describes chunk of memory 

