---
title: "JSON-RPC"
symbol_kind: "intro"
decl_name: "json-rpc.h"
---



